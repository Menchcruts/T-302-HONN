class Pepperoni:
    pass
