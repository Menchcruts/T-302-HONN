class Clams:
    pass
