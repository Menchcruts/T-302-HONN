class Dough:
    pass
