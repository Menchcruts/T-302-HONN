class Veggies:
    pass
