class Sauce:
    pass    
