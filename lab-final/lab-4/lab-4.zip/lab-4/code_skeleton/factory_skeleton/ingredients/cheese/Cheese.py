class Cheese:
    pass
