class PaymentFailedException(Exception):
    pass
